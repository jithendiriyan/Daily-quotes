import './App.css';
import DailyQuote from './components/DailyQuotes.js';

function App() {
  return (
    <div className="App">
      <nav>
        <h1 className='heading'>Quote Of The Day</h1>
      </nav>
      <DailyQuote/>
    </div>
  );
}

export default App;
